<?php
include ("../includes/config.php");
include ("../includes/checksouthead.php");

if ( isset($_GET['q']) )
{

$username = $_SESSION["username"];
$id = $_GET['q'];

$sql= "SELECT id FROM users WHERE username LIKE '$username'";
$result = $dbconnect->query($sql);
$row = $result->fetch_assoc();
$userid = $row["id"];

$sql= "UPDATE notification SET status = 'Seen' WHERE id LIKE '$id' AND userid LIKE '$userid'";
$result = $dbconnect->query($sql);

}

$sql = "SELECT id FROM users WHERE username like '$username'";
$result = $dbconnect->query($sql);
$row = $result->fetch_assoc();
$userid = $row["id"];

$sql="SELECT * FROM notification WHERE userid LIKE '$userid' AND status like 'unseen' ORDER BY id DESC LIMIT 5";
$result = $dbconnect->query($sql);

if ( $result->num_rows > 0 )
{
	echo "<br><b><div style='width: 100%;'>
	<table width='100%'><tr><td style='text-align: left; font-size: 20px;'><a style='color: white;text-decoration: none;' target='' href='notifications.php' >Notification</a></td></tr></table></div></b>";

	echo "<table>";
	while($row = $result->fetch_assoc()) 
	{
		if ( $row["type"] == "request")
		{
			echo "<tr>";
			echo "<td style='width:1%;font-size: 20px; text-decoration: none; color: white'><a onclick='showUser(". $row["id"].")'>&times;</a> </td>";
			echo "<td><a href=".$row["titleid"]." style='text-decoration: none'><b style='color: burlywood'>" . $row['title'] . "</b> is here.</a></td>";
			echo "</tr>";
		}
		elseif ( $row["type"] == "report")
		{
			echo "<tr>";
			echo "<td style='width:1%;font-size: 20px; text-decoration: none; color: white'><a onclick='showUser(". $row["id"].")'>&times;</a> </td>";
			echo "<td><a href=".$row["titleid"]." style='text-decoration: none'>Your report for <b style='color: palevioletred'>" . $row['title'] . "</td></b> is fixed.</a>";
			echo "</tr>";
		}
		elseif ( $row["type"] == "notwached")
		{
			echo "<tr>";
			echo "<td style='width:1%;font-size: 20px; text-decoration: none; color: white'><a onclick='showUser(". $row["id"].")'>&times;</a> </td>";
			echo "<td><a href=watch.php".str_replace('preparevideo.php','',$row['titleid'])." style='text-decoration: none; color:white;'>New from <b style='color: lightgreen'>" . $row['title'] . "</b></a></td>";
			echo "</tr>";
		}
	}
	echo "</table>";
}
?>