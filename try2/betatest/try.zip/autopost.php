<?php
include_once ("includes/config.php");
include_once("includes/checksouthead.php");

$catid = $_GET["id"];
$sql = "SELECT * FROM category WHERE id LIKE $catid";
$result = $dbconnect->query($sql);
$row = $result->fetch_assoc();
$category = $row["title"];
$poster = $row["poster"];
$posttime = date("g:i A");
$postdate = date("Y/m/d");
$subtitle = "";
$type = $row["type"];

strtolower( $search = urlencode($category));
$url = "https://uptobox.com/api/user/files?token=5431418d243f6272e54142975ba2c2ad6uvoo&path=//&limit=100&orderBy=file_name&searchField=file_name&search=".$search;
$return = file_get_contents($url);
$json_a = json_decode($return, true);

$allTitles = array();
$allLinks = array();

$i = 0;
while ( $i < sizeof($json_a['data']['files']) ) 
{
	$title = $json_a['data']['files'][$i]['file_name'];
	$title = strtolower ($title);
	
	if ( strpos($title,"s0") !== false )
	{
		$newtitle = explode("s0",$title);
		$newtitle1 = explode("e",$newtitle[1]);
		$titleNo = "s0" . $newtitle1[0] . "e" ;
		$epiNo = $newtitle1[1];
		$y = 0;
		while ( $y < strlen($epiNo) )
		{
			if ( is_numeric($epiNo[$y]) )
			{
				$titleNo = $titleNo . $epiNo[$y];
			}
			else
			{
				break;
			}
			$y++;
		}
		$allTitles[] = strtoupper($titleNo);
		$allLinks[] = "http://uptobox.com/" . $json_a['data']['files'][$i]['file_code'];
	}
	
	if ( strpos($title,"s1") !== false )
	{
		$newtitle = explode("s1",$title);
		$newtitle1 = explode("e",$newtitle[1]);
		$titleNo = "s1" . $newtitle1[0] . "e" ;
		$epiNo = $newtitle1[1];
		$y = 0;
		while ( $y < strlen($epiNo) )
		{
			if ( is_numeric($epiNo[$y]) )
			{
				$titleNo = $titleNo . $epiNo[$y];
			}
			else
			{
				break;
			}
			$y++;
		}
		$allTitles[] = strtoupper($titleNo);
		$allLinks[] = "http://uptobox.com/" . $json_a['data']['files'][$i]['file_code'];
	}
	
	if ( strpos($title,".e") !== false AND strpos($title,"s0") === false AND strpos($title,"s1") === false)
	{
		$newtitle = explode(".e",$title);
		$newtitle1 = explode(".mp4",$newtitle[1]);
		$titleNo = "s01e" . $newtitle1[0];
		$epiNo = $newtitle1[1];
		$y = 0;
		while ( $y < strlen($epiNo) )
		{
			if ( is_numeric($epiNo[$y]) )
			{
				$titleNo = $titleNo . $epiNo[$y];
			}
			else
			{
				break;
			}
			$y++;
		}
		$allTitles[] = strtoupper($titleNo);
		$allLinks[] = "http://uptobox.com/" . $json_a['data']['files'][$i]['file_code'];
	}
	
	$i++;
}

$i = 0;
while ( $i < sizeof($json_a['data']['files']) )
{
	$sql= "SELECT id FROM posts ORDER BY id DESC LIMIT 1";
	$result = $dbconnect->query($sql);
	$row = $result->fetch_assoc();
	$id = $row["id"]+1;
	
	$sql = "INSERT INTO posts (id,catid, title, category, type, postdate, posttime, views, poster, subtitle, videolink, download) VALUES ('$id', '$catid', '$allTitles[$i]', '$category', '$type', '$postdate', '$posttime', '0', '$poster', '$subtitle', '$allLinks[$i]', '$allLinks[$i]')";
	$result = $dbconnect->query($sql);
	
	$i++;
}

header ("Location: category.php?id=$catid");

?>