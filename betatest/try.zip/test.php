<?php

$firstURL = "https://vi.egybest.vip/movie/%D9%81%D9%8A%D9%84%D9%85-7-kogustaki-mucize-2019-%D9%85%D8%AA%D8%B1%D8%AC%D9%85";

$main = file_get_contents(str_replace("movie","movie/watch",$firstURL));

$main = explode ('<iframe', $main);

$main = explode ('data-src="', $main[1] );

$main = explode ('"',$main[1]);

$url = file_get_contents($main[0]);

$url = explode('source src="', $url );

sizeof($url);

$url = explode ('"', $url[sizeof($url)-1]);

echo $url[0];

?>