<?php
include_once ("includes/config.php");
include_once("includes/checksouthead.php");
if ( !isset ( $_GET["catid"] ) )
{
	$catid = "";
}
else
{
	$catid = $_GET["catid"];
}
if ( !isset ($_SESSION["username"]) )
{
	header ("Location: index.php?error=post");
}
elseif ( $_SESSION["username"] == "admin" )
{

	$sql = "select title from category where id like $catid";
	$result = $dbconnect->query($sql);
	$row = $result->fetch_assoc();
	$title = $row["title"];
?>
<!DOCTYPE html>
<html>
<title>Add Multiple Posts - Q8Flix</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="images/logo.png">
<link rel="stylesheet" href="css/style1.css?dsadsa">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
html,body,h1,h2,h3,h4,h5,h6 {font-family: "Roboto", sans-serif}
</style>

<body>

<!-- Page Container -->
<div class="w3-content" style="max-width:1300px">
<?php
include_once ("template/header.php");
?>
  <!-- The Grid -->
  <div class="">
 

    <!-- Right Column -->
    <div class="w3-text-white" style="padding-top: 40px;">
      <div class="w3-row-padding w3-padding-16 w3-center" id="food" >
		  <?php 
	if (!isset ( $_GET["numberofposts"] ))
	{
	?>
		  <h1>Adding Multiple Posts into <b style="color: red"><?php echo $title ?></b></h1>
		  <form method="get" action="">
			  <table style="width: 100%">
				  <tr>
				  <td style="width: 10%">
				  Number of posts: 
				  </td>
				  <td >
				  <input type="text" name="numberofposts" value=""  style="width: 100%">
				  </td>
				  </tr>
				  <tr>
				  <td style="width: 10%">
			 	  Posts title: 
				  </td>
				  <td>
			      <input type="text" name="poststitle" value="" placeholder="EX. S01E01 or EP01"  style="width: 100%">
				  </td>
				  </tr>
				  <tr>
				  <td></td>
			      <input type="hidden" name="catid" value="<?php echo $_GET["catid"] ?>">
		  	      <td colspan="2">
				  <input type="submit" name="submit" value="Submit" style="width: 100%">
				  </td>
			  </tr></table>
		  </form>
<?php
	}

	if (!isset ($_GET["numberofposts"]) && !isset($_GET["poststitle"]))
	{
		
	}
	else {
$i = 0;
$title = $_GET["poststitle"];
$seasonnumber = strstr($title,'E',true);
$seasonnumber = explode("S",$seasonnumber);
$seasontitle = "S".$seasonnumber[1]."E";
	$sql = "select title from category where id like $catid";
	$result = $dbconnect->query($sql);
	$row = $result->fetch_assoc();
	$catetitle = $row["title"];

if ( strpos($title, 'EP') !== false )
{
	$title = explode("EP",$title);
	$titlevalue = "EP";
	$titlenumber = $title[1];
}
		
elseif (strpos($title, $seasontitle) !== false)
{
	$title = explode($seasontitle,$title);
	$epnumber = $title[1];
}
if ( $_GET["numberofposts"] > 99 AND $_GET["numberofposts"] < 999 )
{
	$strpad = 3;
}
elseif ( $_GET["numberofposts"] > 999 )
{
	$strpad = 4;
}
else
{
	$strpad = 2;
}

		?>
		    <h1>Adding Multiple Posts into <b style="color: wheat"><?php echo $catetitle ?></b></h1>
		  <?php
		while ( $i < $_GET["numberofposts"])
		{
	?>
<form method="post" action="includes/multipostdb.php" enctype="multipart/form-data">
<table align="center" style="width: 100%">
<tr>
<td style="width: 20%;">Subtitle:</td>
<td style="width: 40%;">Title:</td>
<td style="width: 40%;">Category:</td>
</tr>
<tr>
<td><input type="file" name="<?php echo "subtitle".$i ?>" style="width: 100%"></td>
<td><input type="text" style="width: 100%;" name="<?php echo "title".$i ?>" value="<?php if (isset ($titlenumber)) 
	{
		echo $titlevalue.str_pad ($titlenumber, 4, "0", STR_PAD_LEFT);
	} 
			elseif (isset($epnumber))
			{
				echo $seasontitle.str_pad($epnumber, $strpad, "0", STR_PAD_LEFT);
			} ?>"></td>
<td style="width: 100%;"><select style="width: 100%;" name='category'>
<?php 
$result = $dbconnect->query("SELECT title FROM category WHERE id='$catid'");
$row = $result->fetch_assoc();
?>
<option value="<?php echo $row["title"] ?>"><?php echo $row["title"] ?></option>
<?php 

$result = $dbconnect->query("SELECT title FROM category ORDER BY title ASC");
$categoryNew = "naser";
while ($row = $result->fetch_assoc()) 
{
	$category = $row['title'];
	if ( $category != $categoryNew )
	{
		?>
        <option value="<?php echo $category ?>"><?php echo $category ?></option>
		<?php
        $categoryNew = $category;
	}
}
?>
</select></td>
</tr>
<tr>
<td></td>
<?php
	$result = $dbconnect->query("SELECT poster FROM category WHERE id='$catid'");
	$row = $result->fetch_assoc();
	?>
<td><input type="hidden" name="poster" value="<?php echo $row["poster"]; ?>"></td>
</tr>
<tr>
<td></td>
<td><input type="hidden" name="download" value=""></td>
</tr>
<tr>
<td><input type="hidden" name="<?php echo "oldvideolink".$i ?>" value=""></td>
<td><input type="hidden" name="postdate" value="<?php echo date("Y/m/d"); ?>"></td>
<td><input type="hidden" name="posttime" value="<?php echo date("g:i A"); ?>"</td>
<td><input type="hidden" name="catid" value="<?php echo $catid ?>"></td>
<td><input type="hidden" name="subtitle" value=""></td>
<td><input type="hidden" name="numberofposts" value="<?php echo $_GET["numberofposts"] ?>"></td>
</tr>


<?php
	$i=$i+1;
	if (isset ($titlenumber))
	{
		$titlenumber=$titlenumber+1;
	}
	if (isset ($epnumber))
	{
		$epnumber=$epnumber+1;
	}
	}
		?>
	<tr>
		<td colspan="3"><textarea name="videolink" style="width: 100%; height: 300px;"></textarea></td>
	</tr>
	</table>
	<input type="submit" name="submit" value="Submit">
</form>
		  <?php
	}
?>
    <!-- End Right Column -->
    </div>
    </div>
    
  <!-- End Grid -->
	  <?php
}
else
{
	header ("Location: index.php?error=post");
}
include_once ("template/footer.php");
?>
  </div>
  
  <!-- End Page Container -->
</div>


</body>
</html>
