<?php
include ("../includes/config.php");
include ("../includes/checksouthead.php");
$id = $_GET["id"];

if ( isset($_GET["q"]) )
{
	$catid = $_GET["q"];
	$sql= "SELECT id FROM users WHERE username LIKE '$username'";
	$result = $dbconnect->query($sql);
	$row = $result->fetch_assoc();
	$userid = $row["id"];

	$sql1 = "SELECT catids FROM favolist WHERE userid LIKE '$userid'";
	$result = $dbconnect->query($sql1); 
	$row = $result->fetch_assoc();
	$catids = $row["catids"];
	$catids = explode(",",$catids);
		
	if ( !in_array($id,$catids)  )
	{
		$sql= "SELECT id FROM favolist ORDER BY id DESC LIMIT 1";
		$result = $dbconnect->query($sql);
		$row = $result->fetch_assoc();
		$newuserid = $row["id"]+1;

		$sql= "SELECT catids FROM favolist WHERE userid = '$userid'";
		$result = $dbconnect->query($sql);
		if ( $result->num_rows < 1)
		{
			$row = $result->fetch_assoc();
			$catids = "," . $catid;

			$sql = "INSERT INTO favolist (id, userid, catids) VALUES ('$newuserid','$userid','$catids')";
			$result = $dbconnect->query($sql);
		}
		else
		{
			$row = $result->fetch_assoc();
			$catids = $row["catids"];
			$catids = explode(",",$catids);
			if ( !in_array ($catid,$catids) )
			{
				$catids = "," . $catid . $row["catids"];
			}
			$sql = "UPDATE favolist SET catids = '$catids' WHERE userid = '$userid'";
			$result = $dbconnect->query($sql);
		}
	}
	else
	{
		$sql= "SELECT catids FROM favolist WHERE userid = '$userid'";
		$result = $dbconnect->query($sql);
		if ( $result->num_rows > 0)
		{
			$row = $result->fetch_assoc();
			$catids = $row["catids"];
			$catids = explode(",",$catids);
			echo "<br>";
			$favoindex = array_search($catid,$catids);
			$unfovao = "," . $catids[$favoindex];
			$catids = $row["catids"];
			$catids = explode($unfovao,$catids);
			$catids = $catids[0] . $catids[1];
			
			$sql = "UPDATE favolist SET catids = '$catids' WHERE userid = '$userid'";
			$result = $dbconnect->query($sql);
		}
	}
}


$sql = "SELECT id FROM users WHERE username like '$username'";
$result = $dbconnect->query($sql);
$row = $result->fetch_assoc();
$userid = $row["id"];

$sql1 = "SELECT catids FROM favolist WHERE userid LIKE '$userid'";
$result = $dbconnect->query($sql1); 
$row = $result->fetch_assoc();
$catids = $row["catids"];
$catids = explode(",",$catids);
	
if ( in_array($id,$catids)  )
{
	echo "<div align='center' style='width: 100%;'>
	<a onclick='showUser(". $id .")'><img src='images/favoon1.png' style='width: 45px; height: 45px;'></a>
	<div style='font-size: 10px; padding-bottom:5px;'>Unfavorite</div>
	</div>";
}
else
{
	echo "<div align='center'  style='width: 100%;'>
	<a onclick='showUser(". $id .")'><img src='images/favooff1.png' style='width: 45px; height: 45px;'></a>
	<div style='font-size: 10px; padding-bottom:5px;'>Favorite</div>
	</div>";
}

?>