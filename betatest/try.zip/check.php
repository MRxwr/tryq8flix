<!DOCTYPE html>
<html>
<body>

<form action="" method="get" enctype="multipart/form-data">
    Add video link:
    <br><input type="text" name="video" placeholder="enter video link" style="width:500px">
    <br><input type="submit" value="Check Video" name="submit" style="width:500px">
</form>
<br>
	
<?php
if ( isset($_GET["video"]) )
{
	$videolink = $_GET["video"];
?>
<video controls width="500px" height="350px" style="background:black;" autoplay>
<source  src="<?php echo $videolink ?>" type='video/mp4'>
<source src='<?php echo $videolink ?>' type='video/webm'>
<source src='<?php echo $videolink ?>' type='video/ogg'>
	<track src="../subs/24-10-1915718971571571897157.vtt" />
</video>
<?php
}
?>
</body>
</html>



