<?php
include_once ("includes/config.php");
include_once("includes/checksouthead.php");
$catid = $_GET["id"];

if ( !isset ( $_SESSION["username"] ) || $_SESSION["username"] != "admin" )
{
	header ("Location: index.php?error=editcategory");
}
else
{
	?>
<!DOCTYPE html>
<html>
<title>Edit Post - Q8Flix</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="images/favicon.png">
<link rel="stylesheet" href="css/style1.css?dasd">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
html,body,h1,h2,h3,h4,h5,h6 {font-family: "Roboto", sans-serif}
</style>

<body class="">

<!-- Page Container -->
<div class="w3-content" style="max-width:1300px;">
<?php
include_once ("template/header.php");
include_once ("includes/config.php");
$date = date("Y/M/D");
?>
  <!-- The Grid -->
  <div class="">
 

    <!-- Right Column -->
    <div class="w3-text-grey">
      <div class="w3-row-padding w3-padding-16 w3-center" id="food" style="padding-top: 40px;">
  <h1>Edit Post</h1>
<?php		  
	$sql = "SELECT * FROM posts WHERE catid = '$catid' ORDER BY title ASC ";
	$result = $dbconnect->query($sql);
	if ( $result->num_rows > 0 )
	{
		
		$datatitle[] = "";
		while ( $row = $result->fetch_assoc() )
		{
			$titlearray[] = $row["title"];
			$idarray[] = $row["id"];
			$posterarray[] = $row["poster"];
			$videolinkarray[] = $row["videolink"];
		}
	}
		var_dump($totalcategories = sizeof($idarray));
	$i = 0;
	?>
<form method="post" action="includes/editmultipostsdb.php" autocomplete="off">
<table align="center" style="width: 100%">
<tr>
<td>Title:</td>
<td>Poster: </td>
<td>Video Link:</td>
</tr>
<tr>
		  <?php
while ($i < $totalcategories)
{
?>
<td><input type="text" width="100%" name="<?php echo "title".$i ?>" value="<?php echo $titlearray[$i] ?>" style="width: 100%"></td>
<td><input type="text" name="<?php echo "poster".$i ?>" width="100%"  value="<?php echo $posterarray[$i] ?>" style="width: 100%"></td>
<td><input type="text" name="<?php echo "videolink".$i ?>" width="100%"  value="<?php echo $videolinkarray[$i] ?>" style="width: 100%"></td>
</tr>
<tr>
<td><input type="hidden" name="<?php echo "id".$i ?>" value="<?php echo $idarray[$i] ?>">
<td><input type="hidden" name="catid" value="<?php echo $catid ?>"></rd>
</tr>


  <?php
	$i = $i+1;
}
	?>
    <!-- End Right Column -->
	
    <tr>
	<td colspan="4"><input type="submit" name="submit" value="Submit" style="width: 100%"></td>
	</tr>
	<input type="hidden" name="numberofposts" value="<?php echo $totalcategories ?>">
	</table>
</form>
	</div>
    </div>
    
  <!-- End Grid -->
	  <?php
include_once ("template/footer.php");
?>
  </div>
  
  <!-- End Page Container -->
</div>



</body>
</html>
    <?php
}
?>