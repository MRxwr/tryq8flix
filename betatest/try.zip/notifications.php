<!DOCTYPE html>
<html>
<title>Notifications - Q8Flix</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="images/logo.png">
<link rel="stylesheet" href="css/style1.css?dasd">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
html,body,h1,h2,h3,h4,h5,h6 {font-family: "Roboto", sans-serif}
.boxsizingBorder {
    -webkit-box-sizing: border-box;
       -moz-box-sizing: border-box;
            box-sizing: border-box;
}
	/* DivTable.com */
.divTable{
	display: table;
	width: 100%;
}
.divTableRow {
	display: table-row;
}
.divTableHeading {
	background-color: #EEE;
	display: table-header-group;
}
.divTableCell, .divTableHead {
	border: 1px solid #999999;
	display: table-cell;
	padding: 3px 10px;
}
.divTableHeading {
	background-color: #EEE;
	display: table-header-group;
	font-weight: bold;
}
.divTableFoot {
	background-color: #EEE;
	display: table-footer-group;
	font-weight: bold;
}
.divTableBody {
	display: table-row-group;
}
</style>
<script>
function showUser(str) {
    if (window.XMLHttpRequest) 
		{
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } 
		else 
		{
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() 
		{
            if (this.readyState == 4 && this.status == 200) 
			{
                document.getElementById("txtHint").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET","live/notifications_update.php?q="+str,true);
        xmlhttp.send();
    }
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script>
	$(document).ready(function(){
		
		$.ajax({
			url: 'live/notifications_update.php',
			success: function(data){
				
				$("#txtHint").html(data);
			}
		})
	});
</script>
</head>
<body>
<?php
include ("includes/config.php");
include ("includes/checksouthead.php");
include ("template/header.php");
?>
<!-- Right Column -->
    <div class="w3-text-white" style="padding-top: 40px">
      <div class="w3-row-padding w3-padding-16 w3-center">
<?php

$sql = "SELECT id FROM users WHERE username like '$username'";
$result = $dbconnect->query($sql);
$row = $result->fetch_assoc();
$userid = $row["id"];

$sql = "SELECT catids FROM favolist WHERE userid LIKE '$userid'";
$result = $dbconnect->query($sql);
$row = $result->fetch_assoc();
$catids = explode(",",$row["catids"]);
	
$i = 0;
$checkifwatched = array();
while ( $i < sizeof($catids))
{
	$sql = "SELECT id FROM posts WHERE catid LIKE '$catids[$i]' ORDER BY title DESC LIMIT 1";
	$result = $dbconnect->query($sql);
	$row = $result->fetch_assoc();
	$checkifwatched[] = $row["id"];
	$i = $i +1;
}
	
$i = 0;
while ( $i < sizeof($checkifwatched))
{
	$sql = "SELECT postsid FROM finishedwatching WHERE userid LIKE '$userid'";
	$result = $dbconnect->query($sql);
	$row = $result->fetch_assoc();
	$watchedtitles = explode(",",$row["postsid"]);
	if ( !in_array($checkifwatched[$i],$watchedtitles))
	{
		$notwatched[] = $checkifwatched[$i];
	}
	$i = $i +1;
}
	
$i = 0;
if ( isset ($notwatched) )
{
	while ( $i < sizeof($notwatched))
	{
		$sql = "SELECT * FROM posts WHERE id LIKE '$notwatched[$i]'";
		$result = $dbconnect->query($sql);
		$row = $result->fetch_assoc();
		$notwatchedids[] = $row["id"];
		$notwatchedcatids[] = $row["catid"];
		$notwatchedtitles[] = $row["title"];
		$notwatchedcategories[] = $row["category"];
		$i = $i +1;
	}

if ( sizeof($notwatched) > 0 )
	{
		$i = 0 ;
		while ( $i < sizeof($notwatched) )
		{
			$notwatchedlinks = "preparevideo.php?postid=" . $notwatchedids[$i] . "&catid=" . $notwatchedcatids[$i];
			$notwatchedfulltitle = $notwatchedcategories[$i] . " " .$notwatchedtitles[$i];
			$sql = "SELECT * FROM notification WHERE userid LIKE '$userid' ORDER BY id DESC LIMIT 1";
			$result = $dbconnect->query($sql);
			$row = $result->fetch_assoc();
			$notificationlastid = $row["id"] + 1;
			$notificationtype = "notwached";
			$notificationstatus = "unseen";

			$sql = "SELECT * FROM notification WHERE userid LIKE '$userid' AND title LIKE '$notwatchedfulltitle'";
			$result = $dbconnect->query($sql);

			if ( $result->num_rows > 0 )
			{
				goto jump;
			}
			else
			{
				$sql = "INSERT INTO notification (id, userid, type, title, titleid, status) VALUES ('$notificationlastid','$userid', '$notificationtype', '$notwatchedfulltitle', '$notwatchedlinks', '$notificationstatus')";
				$result = $dbconnect->query($sql);
			}
			jump:
			$i = $i + 1;
		}
	}
}

$sql = "SELECT * FROM notification WHERE userid LIKE '$userid' AND status like 'unseen' ORDER BY id DESC ";
$result = $dbconnect->query($sql);
$row = $result->fetch_assoc();
?>

<div id="txtHint" ></div>
</div>
</div>
<?php
include_once ("template/footer.php");
?>
</body>
</html>