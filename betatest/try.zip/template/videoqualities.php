<table style="width: 100%">
	<tr>
	<td>
	<select style="width: 100%" onchange="location = this.options[this.selectedIndex].value;">
        <option value="" >Sort By:</option>	
		<?php if ( !empty($uptobox) )
		{
			?>
			<option value="watch.php?postid=<?php echo $postid ?>&catid=<?php echo $id ?>&srv=u2b" >High Quality</option>
			<option value="preparevideo.php?postid=<?php echo $postid ?>&catid=<?php echo $id ?>&srv=lu2b" >Low Quality</option>
			<?php
		}
		?>
		<?php if ( !empty($youtube) )
		{
			?>
			<option value="watch.php?postid=<?php echo $postid ?>&catid=<?php echo $id ?>&srv=utb" >YouTube</option>
			<?php
		}
		?>
		<?php if ( !empty($mycima) )
		{
			?>
			<option value="watch.php?postid=<?php echo $postid ?>&catid=<?php echo $id ?>&srv=myc" >Server 2</option>
			<?php
		}
		?>
	</select>
	</td>
		<td style="width:33.3%"><a class="myButtonred" href="report.php?postid=<?php echo $postid ?>&catid=<?php echo $id ?>">Report</a>
		</td>
	</tr>
</table>