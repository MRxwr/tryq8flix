		  <?php 
		$result = $dbconnect->query("SELECT collections FROM category WHERE id LIKE '$id'");
		$row = $result->fetch_assoc();
		$collections = explode(",",$row["collections"]);

		$posters = array();
		if ( isset($collections[1]) )
		{
?>
		<h3 style="color: white" class="w3-center">Movie Collection</h3><hr>
<?php
		}
		$i = 0 ;
		while ( $i < sizeof($collections) ) 
		{ 
			$result = $dbconnect->query("SELECT poster FROM category WHERE id LIKE '$collections[$i]'");
			$row = $result->fetch_assoc();
			$posters[] = $row["poster"];
			$i = $i + 1;
		} 
		$i = 0 ;
		while ( $i < sizeof($posters)) 
		{ 
			if ( $collections[$i] !== "" )
			{
?>
				<a href="category.php?id=<?php echo $collections[$i] ?>"><div class="w3-quarterindex" style="padding: 3px;"><img src="<?php echo $posters[$i] ?>" alt="" id="imageindex"></a></div>
<?php
			}
			$i = $i + 1;
		}
?>	