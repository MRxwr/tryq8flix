<div id="videoplayer">
<?php 
if ( strstr($videolink,"drive.google") OR  strstr($videolink,"mycima") OR  strstr($videolink,"youtube"))
{
	?>
	<iframe src="<?php $gyLinks = str_replace("view","preview",$videolink); $gyLinks = str_replace("/watch?v=","/embed/",$videolink); echo $gyLinks ?>" height="350px" width="100%" frameBorder="0" ></iframe>
	<?php
}
else
{
	?>
	<video controls width="100%" height="350px" style="background:black; overflow: hidden;" autoplay poster="<?php echo $categoryposter ?>">
	<source  src="<?php echo $videolink ?>.mp4" type='video/mp4'>
	<source src='<?php echo $videolink ?>.mp4' type='video/webm'>
	<source src='<?php echo $videolink ?>.mp4' type='video/ogg'>
	<track default srclang="ar" label="Arabic" src="<?php echo $videosubtitle ?>">
	</video>
	<?php
}
?>
</div>