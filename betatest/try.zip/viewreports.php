<?php
include_once ("includes/config.php");
include_once("includes/checksouthead.php");

$sql = "SELECT * FROM reports ORDER BY id DESC";
$result = $dbconnect->query($sql);
$numberofreports = $result->num_rows;
while ( $row = $result->fetch_assoc() )
{
	$id[] = $row["id"];
	$userid[] = $row["userid"];
	$postid[] = $row["postid"];
	$catid[] = $row["catid"];
	$issue[] = $row["issue"];
	$description[] = $row["description"];
	$date[] = $row["date"];
	$time[] = $row["time"];
	$status[] = $row["status"];
}

$i = 0;
while ( $i < $numberofreports )
{
	$sql = "SELECT * FROM users WHERE id like $userid[$i] ";
	$result = $dbconnect->query($sql);
	while ( $row = $result->fetch_assoc() )
	{
		$usernames[] = $row["username"];
	}
	$i = $i + 1 ;
}
$i = 0;

?>
<!DOCTYPE html>
<html>
<title>View Reports - Q8Flix</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="images/logo.png">
<link rel="stylesheet" href="css/style1.css?dasd">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
html,body,h1,h2,h3,h4,h5,h6 {font-family: "Roboto", sans-serif}
.boxsizingBorder {
    -webkit-box-sizing: border-box;
       -moz-box-sizing: border-box;
            box-sizing: border-box;
}
	/* DivTable.com */
.divTable{
	display: table;
	width: 100%;
}
.divTableRow {
	display: table-row;
}
.divTableHeading {
	background-color: #EEE;
	display: table-header-group;
}
.divTableCell, .divTableHead {
	border: 1px solid #999999;
	display: table-cell;
	padding: 3px 10px;
}
.divTableHeading {
	background-color: #EEE;
	display: table-header-group;
	font-weight: bold;
}
.divTableFoot {
	background-color: #EEE;
	display: table-footer-group;
	font-weight: bold;
}
.divTableBody {
	display: table-row-group;
}
</style>

<body>
<!-- Page Container -->
<div class="w3-content" style="max-width:1300px">

  <!-- The Grid -->
  <div class="">
  <?php
include_once ("template/header.php");
?>
    <!-- Right Column -->
    <div class="w3-text-white" style="padding-top: 40px">
      <div class="w3-row-padding w3-padding-16 w3-center">
<h2 style="color: white">Users Reports</h2>
    <?php
		if ( $i < $numberofreports )
		{
			while ( $i < $numberofreports )
			{

				if ( $username == "admin" )
				{
					$sql = "SELECT * FROM posts WHERE id = '$postid[$i]'";
					$result = $dbconnect->query($sql);
					$row = $result->fetch_assoc();
					$title = $row["title"];
					$category = $row["category"];

									?>
					<table width="100%" border="1" style="color: black; 
						background: <?php if ( $status[$i] == "Done" ) { echo "green"; } else { echo "darkgrey"; } ?>">
					  <tbody>
						<tr>
						  <td>Username</td>
						  <td width="90%"><?php echo $usernames[$i] ?></td>
						</tr>
						<tr>
						  <td>Title</td>
						  <td width="90%"><a href="<?php echo "watch.php?postid=".$postid[$i]."&catid=".$catid[$i] ?>"><?php echo $category . " " . $title ?></a></td>
						</tr>
						<tr>
						  <td>Issue</td>
						  <td width="90%"><?php echo $issue[$i] ?></td>
						</tr>
						<tr>
						  <td>Description</td>
						  <td width="90%"><?php echo $description[$i] ?></td>
						</tr>
						<tr>
						  <td>Date</td>
						  <td width="90%"><?php echo $date[$i] ?></td>
						</tr>
						<tr>
						  <td>Status</td>
						  <td width="90%"><?php echo $status[$i] ?></td>
						</tr>
						<tr>
						  <td colspan="2"><a href="includes/donereport.php?reportid=<?php echo $id[$i] ?>">Done</a></td>
						</tr>
					  </tbody>
					</table>
							  <p></p>

								<?php
				}
				$i = $i + 1;
			}
		}
		else
		{
			echo "No new reprots has been added.";
		}
    ?>
    
  </div>
    </div>
<?php
include_once ("template/footer.php");
?>
    <!-- End Right Column -->
    </div>


</body>
</html>
