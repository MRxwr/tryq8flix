<?php
include_once ("includes/config.php");
include_once("includes/checksouthead.php");

//geting main data
if ( isset ($_GET["postid"]) )
{
	$postid = $_GET["postid"];
	$sql = "SELECT * FROM posts WHERE id like '$postid'";
	$result = $dbconnect->query($sql);
	$row = $result->fetch_assoc();
	$posttitle = $row["title"];
	if ( $posttitle == "" )
	{
		header("Location: index.php");
	}
}
if ( isset ($_GET["catid"]) )
{
	$id = $_GET["catid"];
	$sql = "SELECT * FROM category WHERE id like '$id'";
	$result = $dbconnect->query($sql);
	$row = $result->fetch_assoc();
	$posttitle = $row["title"];
	if ( $posttitle == "" )
	{
		header("Location: index.php");
	}
}
?>

<!DOCTYPE html>
<html>
<title>Maintenance - Q8Flix</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="images/logo.png">
<link rel="stylesheet" href="css/style1.css?dasd">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="//releases.flowplayer.org/7.0.4/commercial/skin/skin.css">
<style>
html,body,h1,h2,h3,h4,h5,h6 {font-family: "Roboto", sans-serif}
.boxsizingBorder {
    -webkit-box-sizing: border-box;
       -moz-box-sizing: border-box;
            box-sizing: border-box;
}
</style>
<style type="text/css">
  .vjs-default-skin .vjs-control-bar { font-size: 100% }
	</style>
<script src="https://vjs.zencdn.net/ie8/1.1.2/videojs-ie8.min.js"></script>
<!-- CSS  -->

<!-- HTML -->

<body>
<!-- Page Container -->
<div class="w3-content" style="max-width: 1300px">

  <!-- The Grid -->
  <div class="">
 <?php

include_once ("template/header.php");
?> 
    <!-- Left Column -->
    
      <div class="w3-text-grey w3-center" style="padding-top: 40px;">
        <div class="w3-display-container">
			
			<table style="width: 100%; border: 0px;">
				<tr>
					<td>
						<br><h3 style="color: white">The video server is being maintanied for the moment, Please check back again after a while...</h3>
					</td>
				</tr>
				<tr>
					<td>
						<img src="https://i.imgur.com/Ah59Xnb.png" width = "250px" height = "250px">
					</td>
				</tr>
			</table>

        </div>
   </div>
<?php
include_once ("template/footer.php");
?>
    <!-- End Left Column -->
    </div>
    </div>
    
  <!-- End Grid -->
    

  <!-- End Page Container -->
</body>
</html>
