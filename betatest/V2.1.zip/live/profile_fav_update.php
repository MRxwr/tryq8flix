<?php
include ("../includes/config.php");
include ("../includes/checksouthead.php");

if ( isset($_GET["q"]) )
{
	$catid = $_GET["q"];
	$sql= "SELECT id FROM users WHERE username LIKE '$username'";
	$result = $dbconnect->query($sql);
	$row = $result->fetch_assoc();
	$userid = $row["id"];

	$sql= "SELECT catids FROM favolist WHERE userid = '$userid'";
	$result = $dbconnect->query($sql);
	if ( $result->num_rows > 0)
	{
		$row = $result->fetch_assoc();
		$catids = $row["catids"];
		$catids = explode(",",$catids);
		echo "<br>";
		$favoindex = array_search($catid,$catids);
		$unfovao = "," . $catids[$favoindex];
		$catids = $row["catids"];
		$catids = explode($unfovao,$catids);
		$catids = $catids[0] . $catids[1];
		
		$sql = "UPDATE favolist SET catids = '$catids' WHERE userid = '$userid'";
		$result = $dbconnect->query($sql);

	}
}

$sql = "SELECT id FROM users WHERE username like '$username'";
$result = $dbconnect->query($sql);
$row = $result->fetch_assoc();
$userid = $row["id"];

$sql = "SELECT catids FROM favolist WHERE userid LIKE '$userid'";
$result = $dbconnect->query($sql);
$row = $result->fetch_assoc();
$catids = explode(",", $row["catids"]);
$i = 0;
	if ( sizeof($catids) != 0 )
	{
		while ( $i < sizeof($catids))
		{
			$sql = "SELECT * FROM category WHERE id LIKE '$catids[$i]'";
			$result = $dbconnect->query($sql);
			$row = $result->fetch_assoc();
			if ( $row["id"] != "" )
			{
				echo "<a href='category.php?id=".$row["id"]."'><div class='w3-quarterindex' style='padding: 3px;  position: relative;text-align: center;color: white;'><img src='".$row["poster"]."' alt='' id='imageindex'></a>
				<a onclick='showUser(". $row["id"].")'><img src='images/unfavo.png' style='width:25px; height:25px'></a></div>";
			}
			$i = $i +1 ;
		}
		
	}
	else
	{
		echo "No shows has been added yet.";
	}
?>