<?php
// getting data saved into arrays
	
	$sql = "SELECT * FROM posts WHERE type like '%$categoryout%' ORDER BY id DESC";
	$result = $dbconnect->query($sql);
	$lastid = 0;
	$i = 0;
	if ( $result->num_rows > 0 )
	{
		
		$datatitle[] = "";
		while ( $row = $result->fetch_assoc() )
		{
			$catetitle = $row["category"];
			$arrayindex = array_search($catetitle,$datatitle);
			
			if ( $datatitle[$arrayindex] != $catetitle )
			{
				$titlearray[] = $row["title"];
				$categoryarray[] = $row["category"];
				$idarray[] = $row["id"];
				$catidarray[] = $row["catid"];
				$posterarray[] = $row["poster"];
				$subtitlearray[] = $row["subtitle"];
				$downloadarray[] = $row["download"];
			}
			$datatitle[] = $row["category"];
		}
	}
		$totalcategories = sizeof($idarray);

// getting imdb rating 
	
$i = 0;
	
while ( $i < $numberofpostsperpage )
		{
			if ( $i < $totalcategories )
			{
				$sql = "SELECT * FROM category WHERE id ='$catidarray[$i]' ORDER BY id DESC LIMIT 1";
				$result = $dbconnect->query($sql);
				$row = $result->fetch_assoc();
				
				$imdbrating[] = $row["imdbrating"];
				$releasedate[] = $row["releasedate"];
			}
	$i = $i + 1 ;
}

$i = 0;

// posting data into index

			while ( $i < $numberofpostsperpage )
			{
				if ( $i < $totalcategories )
				{
					$sql = "SELECT * FROM posts WHERE catid ='$catidarray[$i]' ORDER BY id DESC LIMIT 1";
					$result = $dbconnect->query($sql);
					$row = $result->fetch_assoc();
					$glose = $row["category"] . " (" . $releasedate[$i] .")";
					
							?>

							<a target="" class="tags" glose="<?php echo $glose; ?>" href="category.php?id=<?php echo $catidarray[$i] ?>">
							<div class="w3-quarterindex" style="padding: 3px;  position: relative;text-align: center;color: white;">
							<img src="<?php echo $posterarray[$i] ?>" alt="" id="imageindex">
							<div style="position: absolute;bottom: 1.5%;right: 1.5%;left: 1%;background: rgba(0, 0, 0, .8);">
							<b id="fontindex"><?php if ( $categoryout != "movie" ){ echo $row["title"];} else { echo "<b style='color:yellow'>IMDb: </b>" . $imdbrating[$i];} ?></b>
							</div>
							</a>


							<?php 
				}
			

							?>
</div>

		<?php				 
    			$i = $i +1;
			}
		?>
<?php
unset($imdbrating);
unset($releasedate);
unset($datatitle);
unset($downloadarray);
unset($subtitlearray);
unset($posterarray);
unset($catidarray);
unset($idarray);
unset($categoryarray);
unset($titlearray);
unset($arrayindex);
unset($catetitle);
unset($datatitle);
?>