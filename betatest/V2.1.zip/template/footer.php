<div style="padding-bottom: 15%;"></div>

<?php 

if ( !isset ($username) || $username != "admin")
{
	?>
<footer class="w3-container w3-cell-row" style="border-top-left-radius: 20px;border-top-right-radius: 20px;position: fixed;bottom: 0;width: 100%;background-color: #2E2E2E;color: white;text-align: center; max-width: 1300px;">
  <div class="w3-cell-row" style="width: 100%; padding-top: 3px">

	  <div align="center" class="w3-cell" style="width: 16.6%;">
	  <a href="index.php"><img src="images/home1.png" style="width: 25px;"></a><div style="font-size: 10px">Home</div>
	  </div>
	  
	  <div align="center" class="w3-cell" style="width: 16.6%;">
	  <a href="newmovies.php"><img src="images/movies.png" style="width: 25px;"></a><div style="font-size: 10px">Movies</div>
	  </div>
	  
	  <div align="center" class="w3-cell" style="width: 16.6%;">
	  <a href="tvshow.php"><img src="images/tvshows.png" style="width: 25px;"></a><div style="font-size: 10px">TV-Shows</div>
	  </div>
	  
	  <div align="center" class="w3-cell" style="width: 16.6%;">
	  <a href="anime.php"><img src="images/animes.png" style="width: 25px;"></a><div style="font-size: 10px">Animes</div>
	  </div>
	  
	  <div align="center" class="w3-cell" style="">
	  <a href="wrestling.php"><img src="images/wrestling.png" style="width: 25px;"></a><div style="font-size: 10px">Wrestling</div>
	  </div>
	  
	  <div align="center" class="w3-cell" style="width: 16.6%;">
	  <a href="profile.php"><img src="images/profile1.png" style="width: 30px;"></a><div style="font-size: 10px">Profile</div>
	  </div>
	  
	</div>
</footer>

<?php 
}
elseif ($username == "admin")
{
	?>
<footer class="w3-container w3-cell-row" style="border-top-left-radius: 20px;border-top-right-radius: 20px;position: fixed;bottom: 0;width: 100%;background-color: #2E2E2E;color: white;text-align: center; max-width: 1300px;">
  <div class="w3-cell-row" style="width: 100%; padding-top: 3px">
	  
	  <div align="center" class="w3-cell" style="width: 20%;">
	  <a href="addcategory1.php"><img src="images/imdb21.png" style="width: 45px;"></a><div style="font-size: 10px">Add IMDB</div>
	  </div>
	  
	  <div align="center" class="w3-cell" style="width: 20%;">
	  <a href="addcategory.php"><img src="images/addcat.png" style="width: 25px;"></a><div style="font-size: 10px">Category</div>
	  </div>
	  
	  <div align="center" class="w3-cell" style="width: 20%;">
	  <a href="index.php"><img src="images/home1.png" style="width: 25px;"></a><div style="font-size: 10px">Home</div>
	  </div>
	  
	  <div align="center" class="w3-cell" style="width: 20%;">
	  <a href="profile.php"><img src="images/profile1.png" style="width: 30px;"></a><div style="font-size: 10px">Profile</div>
	  </div>
	  
	  <div align="center" class="w3-cell" style="">
	  <a href="logout.php"><img src="images/logout1.png" style="width: 25px;"></a><div style="font-size: 10px">Exit</div>
	  </div>
	  
	</div>
</footer>

<?php
}
?>