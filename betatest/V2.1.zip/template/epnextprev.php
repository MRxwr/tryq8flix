<table style="width: 100%">
	<tr>
	<?php 
		if ( $previd >= 0 )
		{ ?>
		<td style="width: 50%">
			<a class="<?php if ( in_array( $allids[$previd] , $watchedposts ) ) {echo 'myButtongreen';} else { echo 'myButton'; } ?>" href="watch.php?postid=<?php echo $allids[$previd] ?>&catid=<?php echo $id ?>"><?php echo $prevepidosetitle ?></a>
		</td>
		<?php 
		}
		
		if ( $nextid < sizeof($allids) )
		{ ?>
		<td style="width: 50%">
			<a class="<?php if ( in_array( $allids[$nextid] , $watchedposts ) ) {echo 'myButtongreen';} else { echo 'myButton'; } ?>" href="watch.php?postid=<?php echo $allids[$nextid] ?>&catid=<?php echo $id ?>"><?php echo $nextepisodetitle ?></a>
		</td>
		<?php 
		} ?>
	</tr>
</table>