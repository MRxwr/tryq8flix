<table style="width: 100%">
	<tr>
		<td style="width:33.3%">
			<a class="<?php if ( !isset($_GET["server"]) ) { echo "myButtongray"; } else { echo "myButton"; } ?>" href="watch.php?postid=<?php echo $postid ?>&catid=<?php echo $id ?>">HQ</a>
		</td>
		<td style="width: 33.3%">
			<a class="<?php if ( !isset($_GET["server"]) ) { echo "myButton"; } else { echo "myButtongray"; } ?>" href="preparevideo.php?postid=<?php echo $postid ?>&catid=<?php echo $id ?>&server=o">LQ</a>
		</td>
		<td style="width:33.3%"><a class="myButtonred" href="report.php?postid=<?php echo $postid ?>&catid=<?php echo $id ?>">Report</a>
		</td>
	</tr>
</table>