<img src="<?php echo $row["poster"] ?>" style="width:100%" alt="Avatar">

        </div>
        <div class="w3-container">
       <p><h2 style="text-align: center" ><?php echo $row["title"] ?></h2>
<?php 
if ( $username != "admin" )
{
?>
<div id="txtHint" ></div>
<?php
}
		
elseif ( $username == "admin" )
{
?>
<div id="txtHint" ></div>

<div align="center" class="w3-cell" style="width: 14.28%;">
<a href="includes/deletecatdb.php?id=<?php echo $id ?>" style="text-decoration: none"><img src="images/delete.png" style="width: 30px; height: 30px;">
<div style="font-size: 10px">Delete Category</div></a>
</div>

<div align="center" class="w3-cell" style="width: 14.28%;">
<a href="editcategory.php?id=<?php echo $id ?>" style="text-decoration: none"><img src="images/edit1.png" style="width: 30px; height: 30px;">
<div style="font-size: 10px">Edit Category</div></a>
</div>

<div align="center" class="w3-cell" style="width: 14.28%;">
<a href="editmultiposts.php?id=<?php echo $id ?>" style="text-decoration: none"><img src="images/multiedit.png" style="width: 30px; height: 30px;">
<div style="font-size: 10px">Multi Editing</div></a>
</div>

<div align="center" class="w3-cell" style="width: 14.28%;">
<a href="addpost.php?catid=<?php echo $id ?>" style="text-decoration: none"><img src="images/addpost1.png" style="width: 30px; height: 30px;">
<div style="font-size: 10px">Single Posting</div></a>
</div>
		  
<div align="center" class="w3-cell" style="width: 14.28%;">
<a href="addmultipleposts.php?catid=<?php echo $id ?>" style="text-decoration: none"><img src="images/addmultipost1.png" style="width: 30px; height: 30px;">
<div style="font-size: 10px">Multi Posting</div></a>
</div>	

<div align="center" class="w3-cell" style="width: 14.28%;">
<a href="autopost.php?id=<?php echo $id ?>" style="text-decoration: none"><img src="images/autoPost.png" style="width: 30px; height: 30px;">
<div style="font-size: 10px">Auto Posting</div></a>
</div>  
		  
<div align="center" class="w3-cell" style="width: 14.28%;">
<a href="includes/updatetitlesdb.php?id=<?php echo $id ?>" style="text-decoration: none"><img src="images/updatepoststitle1.png" style="width: 30px; height: 30px;">
<div style="font-size: 10px">Update Titles</div></a>
</div>

<?php
}
?>