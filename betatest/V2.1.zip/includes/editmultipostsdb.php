<?php
session_start();

if ( !isset ( $_POST["catid"] ) )
{
	$catid = "";
}
else
{
	$catid = $_POST["catid"];
	$numberofposts = $_POST["numberofposts"];
	include_once ("config.php");
	$sql = "SELECT title FROM category WHERE id LIKE '$catid'";
	$result = $dbconnect->query($sql);
	$row = $result->fetch_assoc();
	$category = $row["title"];
	$i = 0;
}

if ( !isset ($_SESSION["username"]) OR  $_SESSION["username"] != "admin")
{
	header ("Location: ../index.php?error=post");
}
else
{
	$i = 0;
	while ( $i < $numberofposts )
	{
	
		$id = $_POST["id$i"];
		$title = $_POST["title$i"];
		$poster = $_POST["poster$i"];
		$videolink = $_POST["videolink$i"];

		$sql = "SELECT title,poster,videolink FROM posts WHERE catid = $catid";
		$result = $dbconnect->query($sql);
		$row = $result->fetch_assoc();

		if ( $title != $row["title"] )
		{
			$sql = "UPDATE posts SET title='$title' WHERE id='$id'";
			$results = $dbconnect->query($sql);
		}
		if ( $poster != $row["poster"] )
		{
			$sql = "UPDATE posts SET poster='$poster' WHERE id='$id'";
			$results = $dbconnect->query($sql);
		}
		if ( $videolink != $row["videolink"] )
		{
			$sql = "UPDATE posts SET videolink='$videolink' WHERE id='$id'";
			$results = $dbconnect->query($sql);
		}
		$i = $i + 1 ;
	
		header ("Location: ../category.php?id=$catid");
}
}

?>