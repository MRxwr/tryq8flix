<?php
//getting user id
$sql = "SELECT id FROM users WHERE username = '$username'";
$result = $dbconnect->query($sql);
$row = $result->fetch_assoc();
$userid = $row["id"];

//updating user wachlist
$sql = "SELECT * FROM finishedwatching WHERE userid = '$userid'";
$result = $dbconnect->query($sql);
$row = $result->fetch_assoc();
$watchedposts = explode(",",$row["postsid"]);
if ( !in_array($postid , $watchedposts) )
{
	$watchedposts = $postid . "," . $row["postsid"];
	$sql = "UPDATE finishedwatching SET postsid = '$watchedposts' WHERE userid = '$userid'";
	$sql = $dbconnect->query($sql);
}

//when the user is already sgined before 
$sql = "SELECT * FROM finishedwatching WHERE userid = '$userid'";
$result = $dbconnect->query($sql);
$row = $result->fetch_assoc();
$watchedposts = explode(",",$row["postsid"]);

if ( $result->num_rows < 1 )
{
	//increment id
	$sql = "SELECT * FROM finishedwatching ORDER BY id DESC LIMIT 1";
	$result = $dbconnect->query($sql);
	$row = $result->fetch_assoc();
	$id = $row["id"]+1;
	
	$watchedposts = $postid . ",";
	
	//if the new user comming
	$sql = "INSERT INTO finishedwatching (id, userid, postsid) VALUES ('$id', '$userid', '$watchedposts')";
	$result = $dbconnect->query($sql);
}
?>