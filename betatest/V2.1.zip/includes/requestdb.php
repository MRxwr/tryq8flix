<?php
session_start ();
if ( !isset ($_SESSION["username"]) )
{
	header ("Location: ../index.php");
}
else
{
include_once ("config.php");

$username = $_SESSION["username"];
$title = $_POST["title"];
$imdblink = $_POST["imdblink"];
$description = $_POST["desctiption"];
$date = $_POST["date"];
$time = $_POST["time"];

$sql= "SELECT id FROM requests ORDER BY id DESC LIMIT 1";
$result = $dbconnect->query($sql);
$row = $result->fetch_assoc();
$id = $row["id"]+1;

$sql = "INSERT INTO requests (id,username, title, imdblink, description, status, date, time) VALUES ('$id', '$username', '$title', '$imdblink', '$description','Processing...', '$date', '$time')";
$result = $dbconnect->query($sql);
	
header ("Location: ../request.php?msg=done");
}

?>