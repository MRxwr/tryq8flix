<?php
session_start ();
if ( !isset ($_SESSION["username"]) )
{
	header ("Location: ../index.php");
}
else
{
	include_once ("config.php");

	$username = $_SESSION["username"];
	if ( $username = "admin")
	{
		$reportid = $_GET["reportid"];

		$sql= "UPDATE reports SET status = 'Done' WHERE id = '$reportid'";
		$result = $dbconnect->query($sql);

		$sql= "SELECT id FROM notification ORDER BY id DESC LIMIT 1";
		$result = $dbconnect->query($sql);
		$row = $result->fetch_assoc();
		$id = $row["id"] + 1;

		$sql= "SELECT * FROM reports WHERE id LIKE '$reportid'";
		$result = $dbconnect->query($sql);
		$row = $result->fetch_assoc();
		$postid = $row["postid"];
		$userid = $row["userid"];
		$catid = $row["catid"];

		$sql= "SELECT * FROM category WHERE id LIKE '$catid'";
		$result = $dbconnect->query($sql);
		$row = $result->fetch_assoc();
		$category = $row["title"];

		$type = "report";

		$title = $category ;
		$titleid = "category.php?id=$catid";
		$status = "unseen";

		$sql = "INSERT INTO notification (id, userid, type, title, titleid, status) VALUES ('$id','$userid', '$type', '$title', '$titleid', '$status')";
		$result = $dbconnect->query($sql);

		header ("Location: ../viewreports.php");
	}
	
}

?>