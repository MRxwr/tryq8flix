<?php
if ( isset ( $_COOKIE["Q8FLiX"] ) )
{
	session_start ();
	include_once ("config.php");
	
	$svdva = $_COOKIE["Q8FLiX"];
	
	$sql = "SELECT username FROM users WHERE keepalive like '%".$svdva."%'";
	$result = $dbconnect->query($sql);
	
	
	if ( $result->num_rows == 1 )
	{
		$row = $result->fetch_assoc();
		$username = $row["username"];
		$_SESSION['username'] = $username;	
	}
	else
	{
		goto jump;
	}
}
elseif ( !isset ( $_COOKIE["Q8FLiX"] ) )
{
	jump:
	header("Location: logout.php");
}