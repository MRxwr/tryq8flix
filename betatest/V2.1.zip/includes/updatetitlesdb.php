<?php

include_once("config.php");

$i = 0;
$y = 0;
$categoryid = $_GET["id"];

$sql = "SELECT * FROM posts WHERE catid = '$categoryid' ORDER BY title ASC";
$result = $dbconnect->query($sql);

var_dump ($loop = mysqli_num_rows($result));
echo "<br>";

while ( $row = $result->fetch_assoc() )
{
	
	$postid[$i] = $row["id"];
	var_dump($title = $row["title"]);
	echo "<br>";
	
	//Between E and EP
	//$title = explode("E",$title);
	//$title = ltrim($title[1], '0');
	//number of zeros
	var_dump($title = str_pad ($title, 3, "0", STR_PAD_LEFT));
	echo "<br>";
	
	//$posttitle[$i] = "S01E".$title;
	$posttitle[$i] = str_replace(".","",$title);
	$i = $i + 1;
}

while ( $y < $loop )
{
	$sql = "UPDATE posts SET title = '$posttitle[$y]' WHERE id = '$postid[$y]'";
	$result = $dbconnect->query($sql);
	$y = $y + 1;
}

header ("Location: ../category.php?id=$categoryid")
?>