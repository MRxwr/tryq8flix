<?php

$id = $_GET["id"];

include_once ("config.php");

$sql = "DELETE FROM category WHERE id = '$id'";
$results = $dbconnect->query($sql);

$sql = "DELETE FROM posts WHERE catid = '$id'";
$results = $dbconnect->query($sql);

$sql = "DELETE FROM favourite WHERE catid = '$id'";
$results = $dbconnect->query($sql);

header ("Location: ../view.php?error=deletecat");

?>