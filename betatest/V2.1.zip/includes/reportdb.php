<?php
session_start ();
if ( !isset ($_SESSION["username"]) )
{
	header ("Location: ../index.php");
}
else
{
include_once ("config.php");

$username = $_SESSION["username"];
$catid = $_POST["catid"];
$postid = $_POST["postid"];
$description = $_POST["desctiption"];
$date = $_POST["date"];
$time = $_POST["time"];
$issue = $_POST["issue"];

$sql= "SELECT id FROM reports ORDER BY id DESC LIMIT 1";
$result = $dbconnect->query($sql);
$row = $result->fetch_assoc();
$id = $row["id"]+1;
	
$sql= "SELECT id FROM users WHERE username = '$username'";
$result = $dbconnect->query($sql);
$row = $result->fetch_assoc();
$userid = $row["id"];

$sql = "INSERT INTO reports (id, userid, catid, postid, issue, description, date, time, status) VALUES ('$id', '$userid', '$catid', '$postid', '$issue','$description', '$date', '$time', 'Processing...')";
$result = $dbconnect->query($sql);
	
header ("Location: ../report.php?msg=done&catid=$catid&postid=$postid");
}

?>