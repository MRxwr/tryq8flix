<?php
session_start ();
if ( !isset ($_SESSION["username"]) )
{
	header ("Location: ../index.php");
}
else
{
	include_once ("config.php");

	$username = $_GET["username"];
	$title = $_GET["title"];

	$sql= "UPDATE requests SET status = 'Done' WHERE username = '$username' AND title = '$title'";
	$result = $dbconnect->query($sql);
	
	$sql= "SELECT id FROM notification ORDER BY id DESC LIMIT 1";
	$result = $dbconnect->query($sql);
	$row = $result->fetch_assoc();
	$id = $row["id"] + 1;
	
	$sql= "SELECT id FROM users WHERE username LIKE '$username'";
	$result = $dbconnect->query($sql);
	$row = $result->fetch_assoc();
	var_dump($userid = $row["id"]);
	
	$type = "request";
	
	$title = $_GET["cattitle"];
	$titleid = "search.php?search=" . str_replace(" ","+",$title);
	$status = "unseen";
	
	$sql = "INSERT INTO notification (id, userid, type, title, titleid, status) VALUES ('$id','$userid', '$type', '$title', '$titleid', '$status')";
	$result = $dbconnect->query($sql);

	header ("Location: ../viewrequests.php");
}

?>