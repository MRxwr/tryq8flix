<?php
//video link from streams.cc
if ( strstr($videolink, "mycima") )
{
	$firstURL = $videolink;
	$main = file_get_contents($firstURL);
	$main = explode ('WatchServersList', $main);
	$main = explode ('href="', $main[1] );
	$main = explode ('"',$main[1]);
	$videolink =  $main[0];
	$downloadlink = $videolink;
}
elseif ( strstr($videolink,"streamz") )
{
	$videolink = str_replace("getlink-","f",$videolink);
	$videolink = str_replace(".dll","",$videolink);
	$getfilecode = file_get_contents($videolink);
	$search1 = explode('https://streamz.cc/download',$getfilecode);
	$search2 = explode('"',$search1[1]);
	$getfilecode = $search2[0];
	if ( isset($getfilecode) )
	{
		$videolink = "https://streamz.cc/getlink-" . $getfilecode . ".dll";
		$downloadlink = $videolink;
		$vlclink = explode("https://",$videolink);
		$vlclink = $vlclink[1];
	}
}
//video link with uptobox link in,
elseif (  strstr($videolink,"https://uptobox.com/") AND !isset($_GET["server"]) )
{
	$streamlink = explode("https://uptobox.com/",$videolink);
	$streamlink = $streamlink[1];
	$string = file_get_contents("https://uptobox.com/api/link?token=c7592f3d7e8a2c6682fb51ebd2e9d96f725fl&file_code=".$streamlink);
	if ( $string == NULL )
	{
		header("Location: maintenance.php");
	}
		$json_a = json_decode($string, true);
		$jsonIterator = new RecursiveIteratorIterator( new RecursiveArrayIterator(json_decode($string, TRUE)), RecursiveIteratorIterator::SELF_FIRST);
		foreach ($jsonIterator as $key => $val) 
		{
			if(is_array($val)) 
			{
				"$key:\n";
			} 
			else 
			{
				if ( $key == "dlLink" )
				{
					$videolink = $val;
				}	
			}
		}
	$downloadlink = $videolink;
	$vlclink = explode("https://" , $videolink);
	$vlclink = $vlclink[1];
}
//video link with uptobox link in,
elseif (  strstr($videolink,"http://uptobox.com/") AND !isset($_GET["server"]) )
{
	$streamlink = explode("http://uptobox.com/",$videolink);
	$streamlink = $streamlink[1];
	$string = file_get_contents("https://uptobox.com/api/link?token=c7592f3d7e8a2c6682fb51ebd2e9d96f725fl&file_code=".$streamlink);
	if ( $string == NULL )
	{
		header("Location: maintenance.php");
	}
		$json_a = json_decode($string, true);
		$jsonIterator = new RecursiveIteratorIterator( new RecursiveArrayIterator(json_decode($string, TRUE)), RecursiveIteratorIterator::SELF_FIRST);
		foreach ($jsonIterator as $key => $val) 
		{
			if(is_array($val)) 
			{
				"$key:\n";
			} 
			else 
			{
				if ( $key == "dlLink" )
				{
					$videolink = $val;
				}	
			}
		}
	$downloadlink = $videolink;
	$vlclink = explode("https://" , $videolink);
	$vlclink = $vlclink[1];
}
elseif ( strstr($videolink,"drive.google") )
{
	$videolink = $row["videolink"];
	$downloadlink = $videolink;
	$vlclink = "";
}
elseif ( strstr($videolink,"youtube") )
{
	$videolink = $row["videolink"];
	$downloadlink = $videolink;
	$vlclink = "";
}
//get uptobox link
elseif (strstr($videolink,"https://uptobox.com/") === false AND !isset($_GET["server"]))
{
	$streamlink = $videolink ;
	$string = file_get_contents("https://uptobox.com/api/link?token=c7592f3d7e8a2c6682fb51ebd2e9d96f725fl&file_code=".$streamlink);
	if ( $string == NULL )
	{
		header("Location: maintenance.php");
	}
		$json_a = json_decode($string, true);
		$jsonIterator = new RecursiveIteratorIterator( new RecursiveArrayIterator(json_decode($string, TRUE)), RecursiveIteratorIterator::SELF_FIRST);
		foreach ($jsonIterator as $key => $val) 
		{
			if(is_array($val)) 
			{
				"$key:\n";
			} 
			else 
			{
				if ( $key == "dlLink" )
				{
					$videolink = $val;
				}	
			}
		}
	$downloadlink = $videolink;
	$vlclink = explode("https://" , $videolink);
	$vlclink = $vlclink[1];
}
//get uptobox low quailty
if ( isset($_GET["server"] ) AND $_GET["server"] == "o" AND strstr($videolink,"drive.google") === false )
{
	if ( strstr($videolink, "uptobox") )
	{
		$streamlink = explode("https://uptobox.com/",$videolink);
		$streamlink = $streamlink[1];
	}
	else
	{
		$streamlink = $videolink;
	}
	$string = file_get_contents("https://api.alldebrid.com/link/unlock?agent=mySoft&token=0dcce2b9dfd1a68c93bc891040d0a0b128gn5&link=https://uptobox.com/".$streamlink);
	$json_a = json_decode($string, true);

	if ( isset ($json_a["infos"]["streams"][0]["link"]) )
	{
		$videolink = $json_a["infos"]["streams"][0]["link"] ;
	}
	$downloadlink = $videolink;
	$vlclink = explode("https://" , $videolink);
	$vlclink = $vlclink[1];
}
?>