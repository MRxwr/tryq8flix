<?php
include_once ("includes/config.php");
include_once("includes/checksouthead.php");

?>
<!DOCTYPE html>
<html>
<title>Add Category - Q8FLiX</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="images/logo.png">
<link rel="stylesheet" href="css/style.css?dasd">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
html,body,h3,h2,h3,h4,h5,h6 {font-family: "Roboto", sans-serif}
</style>

<body>

<!-- Page Container -->
<div class="w3-content" style="max-width: 1300px">

	<!-- The Grid -->
  <div class="">
	  
<?php
include_once ("template/header.php");
?>
    <!-- Right Column -->
    <div class="w3-text-white" style="padding-top: 40px">
      <div class="w3-row-padding w3-padding-16 w3-center" id="food" >
		  
		  <table style="width: 100%">
		  <tr>
			  <td style="width: 33.3%">
				  <h3>Period</h3>
			  </td>
			  <td style="width: 33.3%">
				  <h3>Price</h3>
			  </td>
			  <td style="width: 33.3%">
				  <h3>Payment</h3>
			  </td>
		  </tr>
		  <tr>
			  <td>
				  <h3>30 days</h3>
			  </td>
			  <td>
				  <h3><b style="color: darkgoldenrod"> $5.99</b></h3>
			  </td>
			  <td>
				<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
					<input type="hidden" name="cmd" value="_s-xclick">
					<input type="hidden" name="hosted_button_id" value="CDE6WYZVDSDZA">
					<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_paynow_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
					<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
				</form>
			  </td>
		  </tr>
		  <tr>
			  <td>
				   <h3>60 days</h3>
			  </td>
			  <td>
				   <h3><b style="color: darkgoldenrod"> $9.99</b></h3>
			  </td>
			  <td>
				<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
					<input type="hidden" name="cmd" value="_s-xclick">
					<input type="hidden" name="hosted_button_id" value="88W8ZM4AHXQNY">
					<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_paynow_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
					<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
				</form>
			  </td>
		  </tr>
		  <tr>
			  <td>
				  <h3>90 days</h3>
			  </td>
			  <td>
				  <h3><b style="color: darkgoldenrod"> $14.99</b></h3>
			  </td>
			  <td>
				<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
					<input type="hidden" name="cmd" value="_s-xclick">
					<input type="hidden" name="hosted_button_id" value="KU983FJA39XS2">
					<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_paynow_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
					<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
				</form>
			  </td>
		  </tr>
		  </table>
		  
    <!-- End Right Column -->
    </div>
    </div>
    
  <!-- End Grid -->
  </div>
  
  <!-- End Page Container -->


<?php
include_once ("template/footer.php");
?>
</div>
</body>
</html>
